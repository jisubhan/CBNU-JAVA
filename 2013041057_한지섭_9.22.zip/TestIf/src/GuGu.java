
import java.util.Scanner;
public class GuGu {

	public static void main(String[] args) {
		int g;
		while(true) {
		System.out.println("1~9������ ���� �Է��ϼ���");
		Scanner scan = new Scanner(System.in);
		
		if(scan.hasNextInt()) {
			g = scan.nextInt();
			if(g>=1&&g<=9) {
				for(int i=1;i<=g;i++) {
					System.out.println(g+"*"+i+"="+g*i);
				}
				break;
			}
			else
				continue;
		}
		else
			System.out.println("�Է¿���");
		}
	}
				
	}
